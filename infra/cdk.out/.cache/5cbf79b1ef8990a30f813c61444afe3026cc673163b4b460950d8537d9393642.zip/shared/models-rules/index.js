"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserIdFromRequest = getUserIdFromRequest;
function getUserIdFromRequest(request) {
    return request.user && request.user.id;
}
//# sourceMappingURL=index.js.map