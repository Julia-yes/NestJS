import { CartItem } from '../models';
export declare function calculateCartTotal(items: CartItem[]): number;
