export declare const JWT_CONFIG: {
    secret: string;
    expiresIn: string;
};
