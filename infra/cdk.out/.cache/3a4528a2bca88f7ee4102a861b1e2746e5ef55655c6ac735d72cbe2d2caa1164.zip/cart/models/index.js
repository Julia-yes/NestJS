"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CartStatuses = void 0;
var CartStatuses;
(function (CartStatuses) {
    CartStatuses["OPEN"] = "OPEN";
    CartStatuses["STATUS"] = "STATUS";
})(CartStatuses || (exports.CartStatuses = CartStatuses = {}));
//# sourceMappingURL=index.js.map