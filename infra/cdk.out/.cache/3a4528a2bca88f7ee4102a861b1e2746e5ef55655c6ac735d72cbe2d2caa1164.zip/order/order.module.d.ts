export declare class OrderModule {
}
