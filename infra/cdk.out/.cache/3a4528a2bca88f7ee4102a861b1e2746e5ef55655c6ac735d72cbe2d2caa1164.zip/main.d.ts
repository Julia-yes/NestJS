export declare function createApp(): Promise<import("@nestjs/common").INestApplication<any>>;
